<?php
// Heading
$_['heading_title'] = 'Операция не выполнена!';

// Text
$_['text_error']    = 'Причина:  ';
?>