<?php
// Text
$_['text_title'] = '<b>Visa, MasterCard, Maestro</b><b style="color: #FCBA24;"> (E<span style="color: #008CB0;">pay)</span></b>';
$_['text_note'] = 'Вы будете переадресованы на сайт платежной системы <b style="color: #FCBA24;"> E</b><span style="color: #008CB0;">pay</span> Казкоммерцбанка <br/> Заказ поступит в обработку после поступления средств на наш счет.';
$_['error_text_danger'] = 'Документ на отправку в банк возможно подготовлен неправильно!';
$_['error_text_declined'] = 'Банк отклонил карту!';
$_['error_text_reversed'] = 'Операция отменена пользователем!';
$_['error_text_error'] = 'Ответ банка не прошел проверку сертификатом!';
?>