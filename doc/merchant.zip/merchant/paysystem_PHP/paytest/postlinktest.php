<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>��&quot;����&quot;</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Language" content="ru">
</head>
<body bottommargin="0" leftmargin="0" rightmargin="0" topmargin="0" background="../images/bg.gif"> 
<center>
<form name="form1" method="post" action="postlink.php">
<textarea name="response" cols="150" rows="20">
</textarea><br>
<input name="Submit" type="submit" value="Submit">
</form>
</center>
</body>
</html>
